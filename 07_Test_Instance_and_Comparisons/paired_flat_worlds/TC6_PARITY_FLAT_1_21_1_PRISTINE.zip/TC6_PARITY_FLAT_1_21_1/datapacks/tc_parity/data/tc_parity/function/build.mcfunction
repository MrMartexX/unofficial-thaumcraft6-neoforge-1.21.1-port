# Generated parity fixture: global construction, once per world.
kill @e[tag=tc_parity_target]
gamerule doDaylightCycle false
gamerule doWeatherCycle false
gamerule doMobSpawning false
gamerule randomTickSpeed 0
gamerule keepInventory true
gamerule commandBlockOutput false
gamerule sendCommandFeedback false
gamerule spawnRadius 0
time set 6000
weather clear
setworldspawn 0 64 -12
fill -32 63 -16 32 63 40 minecraft:stone
fill -30 64 -14 30 70 38 minecraft:air
fill -28 63 -2 -2 63 -2 minecraft:light_blue_wool
fill -28 63 14 -2 63 14 minecraft:light_blue_wool
fill -28 63 -2 -28 63 14 minecraft:light_blue_wool
fill -2 63 -2 -2 63 14 minecraft:light_blue_wool
fill 2 63 -2 28 63 -2 minecraft:yellow_wool
fill 2 63 14 28 63 14 minecraft:yellow_wool
fill 2 63 -2 2 63 14 minecraft:yellow_wool
fill 28 63 -2 28 63 14 minecraft:yellow_wool
fill -28 63 18 -2 63 18 minecraft:lime_wool
fill -28 63 38 -2 63 38 minecraft:lime_wool
fill -28 63 18 -28 63 38 minecraft:lime_wool
fill -2 63 18 -2 63 38 minecraft:lime_wool
fill 2 63 18 28 63 18 minecraft:red_wool
fill 2 63 38 28 63 38 minecraft:red_wool
fill 2 63 18 2 63 38 minecraft:red_wool
fill 28 63 18 28 63 38 minecraft:red_wool
setblock -24 64 3 minecraft:stone
setblock -20 64 3 minecraft:cobblestone
setblock -16 64 3 minecraft:gravel
setblock -12 64 3 minecraft:glass
setblock -8 64 3 minecraft:coal_ore
setblock -24 64 9 minecraft:iron_ore
setblock -20 64 9 minecraft:gold_ore
setblock -16 64 9 minecraft:lapis_ore
setblock -12 64 9 minecraft:redstone_ore
setblock -8 64 9 minecraft:diamond_ore
fill 14 64 6 14 67 11 minecraft:stone
fill 10 64 23 10 67 28 minecraft:stone
fill 21 68 24 27 68 30 minecraft:stone
summon minecraft:zombie 24.5 64 27.5 {NoAI:1b,PersistenceRequired:1b,Silent:1b,Tags:["tc_parity_target"]}
summon minecraft:cow 24.5 64 22.5 {NoAI:1b,PersistenceRequired:1b,Silent:1b,Tags:["tc_parity_target"]}
setblock -26 64 -7 minecraft:chest[facing=north]{Items: [{id: "minecraft:oak_planks", count: 64, Slot: 0b}, {id: "minecraft:stone", count: 64, Slot: 1b}, {id: "minecraft:gravel", count: 64, Slot: 2b}, {id: "minecraft:diamond_ore", count: 64, Slot: 3b}, {id: "minecraft:chest", count: 16, Slot: 4b}, {id: "minecraft:diamond", count: 16, Slot: 5b}, {id: "thaumcraft:caster_basic", count: 1, components: {"thaumcraft:caster_focus": {focus_item: "thaumcraft:focus_3", custom_name: "Exchange Normal", package: {nodes: "0|root|-1|1|;1|thaumcraft.touch|0|2|;2|thaumcraft.exchange|1||fortune=0,silk=0", complexity: 5, color: 5735255, sorting_hash: 0}}, "thaumcraft:caster_picked_block": [{slot: 0, item: {id: "minecraft:oak_planks", count: 1}}], "minecraft:custom_name": '{"text": "Exchange Normal", "italic": false}'}, Slot: 6b}, {id: "thaumcraft:caster_basic", count: 1, components: {"thaumcraft:caster_focus": {focus_item: "thaumcraft:focus_3", custom_name: "Exchange Silk", package: {nodes: "0|root|-1|1|;1|thaumcraft.touch|0|2|;2|thaumcraft.exchange|1||fortune=0,silk=1", complexity: 5, color: 5735255, sorting_hash: 0}}, "thaumcraft:caster_picked_block": [{slot: 0, item: {id: "minecraft:oak_planks", count: 1}}], "minecraft:custom_name": '{"text": "Exchange Silk", "italic": false}'}, Slot: 7b}, {id: "thaumcraft:caster_basic", count: 1, components: {"thaumcraft:caster_focus": {focus_item: "thaumcraft:focus_3", custom_name: "Exchange Fortune IV", package: {nodes: "0|root|-1|1|;1|thaumcraft.touch|0|2|;2|thaumcraft.exchange|1||fortune=4,silk=0", complexity: 17, color: 5735255, sorting_hash: 0}}, "thaumcraft:caster_picked_block": [{slot: 0, item: {id: "minecraft:oak_planks", count: 1}}], "minecraft:custom_name": '{"text": "Exchange Fortune IV", "italic": false}'}, Slot: 8b}], CustomName: '{"text": "Exchange supplies"}'} replace
setblock -20 64 12 minecraft:chest[facing=north]{Items: [{id: "minecraft:diamond", count: 4, Slot: 0b}], CustomName: '{"text": "Replace me: 4 diamonds"}'} replace
setblock 4 64 -7 minecraft:chest[facing=north]{Items: [{id: "thaumcraft:golem", count: 1, components: {"minecraft:custom_data": {props: 0L, xp: 0}, "minecraft:custom_name": '{"text": "Wood walker", "italic": false}'}, Slot: 0b}, {id: "thaumcraft:golem", count: 1, components: {"minecraft:custom_data": {props: 72340168526266368L, xp: 0}, "minecraft:custom_name": '{"text": "Iron smart fine", "italic": false}'}, Slot: 1b}, {id: "thaumcraft:golem", count: 1, components: {"minecraft:custom_data": {props: 144115196665790464L, xp: 0}, "minecraft:custom_name": '{"text": "Clay climber", "italic": false}'}, Slot: 2b}, {id: "thaumcraft:golem", count: 1, components: {"minecraft:custom_data": {props: 216455369487024128L, xp: 0}, "minecraft:custom_name": '{"text": "Brass flyer", "italic": false}'}, Slot: 3b}, {id: "thaumcraft:golem", count: 1, components: {"minecraft:custom_data": {props: 288795525161943040L, xp: 0}, "minecraft:custom_name": '{"text": "Thaumium fighter", "italic": false}'}, Slot: 4b}, {id: "thaumcraft:golem", count: 1, components: {"minecraft:custom_data": {props: 360855318223126528L, xp: 0}, "minecraft:custom_name": '{"text": "Void dart fighter", "italic": false}'}, Slot: 5b}, {id: "thaumcraft:golem_bell", count: 1, Slot: 6b}, {id: "minecraft:lead", count: 16, Slot: 7b}], CustomName: '{"text": "Golems: place to own"}'} replace
setblock 6 64 4 minecraft:chest[facing=north]{Items: [{id: "minecraft:iron_ingot", count: 32, Slot: 0b}, {id: "minecraft:gold_ingot", count: 16, Slot: 1b}], CustomName: '{"text": "Transfer source"}'} replace
setblock 24 64 4 minecraft:chest[facing=north]{Items: [], CustomName: '{"text": "Transfer destination"}'} replace
setblock -26 64 17 minecraft:chest[facing=north]{Items: [{id: "thaumcraft:seal_pickup", count: 4, Slot: 0b}, {id: "thaumcraft:seal_pickup_advanced", count: 4, Slot: 1b}, {id: "thaumcraft:seal_fill", count: 4, Slot: 2b}, {id: "thaumcraft:seal_fill_advanced", count: 4, Slot: 3b}, {id: "thaumcraft:seal_empty", count: 4, Slot: 4b}, {id: "thaumcraft:seal_empty_advanced", count: 4, Slot: 5b}, {id: "thaumcraft:seal_harvest", count: 4, Slot: 6b}, {id: "thaumcraft:seal_butcher", count: 4, Slot: 7b}, {id: "thaumcraft:seal_guard", count: 4, Slot: 8b}, {id: "thaumcraft:seal_guard_advanced", count: 4, Slot: 9b}, {id: "thaumcraft:seal_lumber", count: 4, Slot: 10b}, {id: "thaumcraft:seal_breaker", count: 4, Slot: 11b}, {id: "thaumcraft:seal_use", count: 4, Slot: 12b}, {id: "thaumcraft:seal_provider", count: 4, Slot: 13b}, {id: "thaumcraft:seal_stock", count: 4, Slot: 14b}, {id: "thaumcraft:seal_breaker_advanced", count: 4, Slot: 15b}], CustomName: '{"text": "All sixteen seals"}'} replace
setblock -23 64 25 minecraft:stone
setblock -19 64 25 minecraft:stone
setblock -15 64 25 minecraft:stone
setblock -11 64 25 minecraft:stone
setblock -7 64 25 minecraft:stone
setblock -3 64 25 minecraft:stone
setblock -18 64 31 minecraft:chest[facing=north]{Items: [{id: "minecraft:iron_ingot", count: 16, Slot: 0b}, {id: "minecraft:oak_planks", count: 32, Slot: 1b}], CustomName: '{"text": "Seal inventory"}'} replace
setblock -25 64 -3 minecraft:oak_sign[rotation=8]{front_text: {messages: ['{"text": "EXCHANGE"}', '{"text": "Normal / Silk"}', '{"text": "Fortune IV"}', '{"text": "Sources ahead"}']}, back_text: {messages: ['{"text": "EXCHANGE"}', '{"text": "Normal / Silk"}', '{"text": "Fortune IV"}', '{"text": "Sources ahead"}']}}
setblock 5 64 -3 minecraft:oak_sign[rotation=8]{front_text: {messages: ['{"text": "GOLEMS"}', '{"text": "Place from chest"}', '{"text": "Owner = placer"}', '{"text": "Transfer / wall"}']}, back_text: {messages: ['{"text": "GOLEMS"}', '{"text": "Place from chest"}', '{"text": "Owner = placer"}', '{"text": "Transfer / wall"}']}}
setblock -25 64 20 minecraft:oak_sign[rotation=8]{front_text: {messages: ['{"text": "SEALS"}', '{"text": "16 types in chest"}', '{"text": "Place on stone"}', '{"text": "Bell: configure"}']}, back_text: {messages: ['{"text": "SEALS"}', '{"text": "16 types in chest"}', '{"text": "Place on stone"}', '{"text": "Bell: configure"}']}}
setblock 5 64 20 minecraft:oak_sign[rotation=8]{front_text: {messages: ['{"text": "COMBAT / REVEAL"}', '{"text": "Zombie under roof"}', '{"text": "Wall for reveal"}', '{"text": "Cow for scanning"}']}, back_text: {messages: ['{"text": "COMBAT / REVEAL"}', '{"text": "Zombie under roof"}', '{"text": "Wall for reveal"}', '{"text": "Cow for scanning"}']}}
tellraw @a {"text":"TC6 parity stations ready. Fresh research; /function tc_parity:unlock is optional.","color":"gold"}
data modify storage tc_parity:state built set value 1b
