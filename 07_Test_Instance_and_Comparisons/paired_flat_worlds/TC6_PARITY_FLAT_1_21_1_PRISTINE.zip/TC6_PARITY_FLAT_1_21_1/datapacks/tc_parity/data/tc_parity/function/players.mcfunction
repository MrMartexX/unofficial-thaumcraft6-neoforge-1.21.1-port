execute unless data storage tc_parity:state built run function tc_parity:build
execute as @a[tag=!tc_parity_ready] run function tc_parity:kit
