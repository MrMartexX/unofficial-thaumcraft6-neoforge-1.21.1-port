tc research @s all
