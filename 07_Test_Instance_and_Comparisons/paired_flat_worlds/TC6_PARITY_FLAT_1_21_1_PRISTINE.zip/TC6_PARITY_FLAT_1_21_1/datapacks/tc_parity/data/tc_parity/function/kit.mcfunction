gamemode creative @s
tp @s 0.5 64 -12.5 0 0
spawnpoint @s 0 64 -12
give @s thaumcraft:thaumonomicon 1
give @s thaumcraft:thaumometer 1
give @s thaumcraft:golem_bell 1
give @s thaumcraft:caster_basic[thaumcraft:caster_focus={focus_item: "thaumcraft:focus_3", custom_name: "Exchange Normal", package: {nodes: "0|root|-1|1|;1|thaumcraft.touch|0|2|;2|thaumcraft.exchange|1||fortune=0,silk=0", complexity: 5, color: 5735255, sorting_hash: 0}},thaumcraft:caster_picked_block=[{slot: 0, item: {id: "minecraft:oak_planks", count: 1}}],minecraft:custom_name='{"text": "Exchange Normal", "italic": false}'] 1
give @s thaumcraft:caster_basic[thaumcraft:caster_focus={focus_item: "thaumcraft:focus_3", custom_name: "Exchange Silk", package: {nodes: "0|root|-1|1|;1|thaumcraft.touch|0|2|;2|thaumcraft.exchange|1||fortune=0,silk=1", complexity: 5, color: 5735255, sorting_hash: 0}},thaumcraft:caster_picked_block=[{slot: 0, item: {id: "minecraft:oak_planks", count: 1}}],minecraft:custom_name='{"text": "Exchange Silk", "italic": false}'] 1
give @s thaumcraft:caster_basic[thaumcraft:caster_focus={focus_item: "thaumcraft:focus_3", custom_name: "Exchange Fortune IV", package: {nodes: "0|root|-1|1|;1|thaumcraft.touch|0|2|;2|thaumcraft.exchange|1||fortune=4,silk=0", complexity: 17, color: 5735255, sorting_hash: 0}},thaumcraft:caster_picked_block=[{slot: 0, item: {id: "minecraft:oak_planks", count: 1}}],minecraft:custom_name='{"text": "Exchange Fortune IV", "italic": false}'] 1
give @s minecraft:oak_planks 64
give @s minecraft:stone 64
give @s minecraft:chest 16
tag @s add tc_parity_ready
tellraw @s {"text":"Kit ready. Golems/seals are in labelled chests. Research is intentionally fresh.","color":"green"}
