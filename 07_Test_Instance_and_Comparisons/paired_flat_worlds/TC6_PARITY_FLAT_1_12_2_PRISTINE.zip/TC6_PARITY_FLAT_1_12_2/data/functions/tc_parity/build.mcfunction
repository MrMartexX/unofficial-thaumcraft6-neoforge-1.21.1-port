# Generated parity fixture: global construction, once per world.
kill @e[tag=tc_parity_target]
gamerule doDaylightCycle false
gamerule doWeatherCycle false
gamerule doMobSpawning false
gamerule randomTickSpeed 0
gamerule keepInventory true
gamerule commandBlockOutput false
gamerule sendCommandFeedback false
gamerule spawnRadius 0
time set 6000
weather clear
setworldspawn 0 64 -12
fill -32 63 -16 32 63 40 minecraft:stone
fill -30 64 -14 30 70 38 minecraft:air
fill -28 63 -2 -2 63 -2 minecraft:wool 3
fill -28 63 14 -2 63 14 minecraft:wool 3
fill -28 63 -2 -28 63 14 minecraft:wool 3
fill -2 63 -2 -2 63 14 minecraft:wool 3
fill 2 63 -2 28 63 -2 minecraft:wool 4
fill 2 63 14 28 63 14 minecraft:wool 4
fill 2 63 -2 2 63 14 minecraft:wool 4
fill 28 63 -2 28 63 14 minecraft:wool 4
fill -28 63 18 -2 63 18 minecraft:wool 5
fill -28 63 38 -2 63 38 minecraft:wool 5
fill -28 63 18 -28 63 38 minecraft:wool 5
fill -2 63 18 -2 63 38 minecraft:wool 5
fill 2 63 18 28 63 18 minecraft:wool 14
fill 2 63 38 28 63 38 minecraft:wool 14
fill 2 63 18 2 63 38 minecraft:wool 14
fill 28 63 18 28 63 38 minecraft:wool 14
setblock -24 64 3 minecraft:stone
setblock -20 64 3 minecraft:cobblestone
setblock -16 64 3 minecraft:gravel
setblock -12 64 3 minecraft:glass
setblock -8 64 3 minecraft:coal_ore
setblock -24 64 9 minecraft:iron_ore
setblock -20 64 9 minecraft:gold_ore
setblock -16 64 9 minecraft:lapis_ore
setblock -12 64 9 minecraft:redstone_ore
setblock -8 64 9 minecraft:diamond_ore
fill 14 64 6 14 67 11 minecraft:stone
fill 10 64 23 10 67 28 minecraft:stone
fill 21 68 24 27 68 30 minecraft:stone
summon minecraft:zombie 24.5 64 27.5 {NoAI:1b,PersistenceRequired:1b,Silent:1b,Tags:["tc_parity_target"]}
summon minecraft:cow 24.5 64 22.5 {NoAI:1b,PersistenceRequired:1b,Silent:1b,Tags:["tc_parity_target"]}
setblock -26 64 -7 minecraft:chest 2 replace {Items: [{id: "minecraft:planks", Count: 64b, Damage: 0s, Slot: 0b}, {id: "minecraft:stone", Count: 64b, Damage: 0s, Slot: 1b}, {id: "minecraft:gravel", Count: 64b, Damage: 0s, Slot: 2b}, {id: "minecraft:diamond_ore", Count: 64b, Damage: 0s, Slot: 3b}, {id: "minecraft:chest", Count: 16b, Damage: 0s, Slot: 4b}, {id: "minecraft:diamond", Count: 16b, Damage: 0s, Slot: 5b}, {id: "thaumcraft:caster_basic", Count: 1b, Damage: 0s, tag: {focus: {id: "thaumcraft:focus_3", Count: 1b, Damage: 0s, tag: {package: {power: 1.0f, complexity: 5, nodes: [{type: "MEDIUM", key: "ROOT"}, {type: "MEDIUM", key: "thaumcraft.TOUCH"}, {type: "EFFECT", key: "thaumcraft.EXCHANGE", setting.fortune: 0, setting.silk: 0}]}}}, picked: {id: "minecraft:planks", Count: 1b, Damage: 0s}, display: {Name: "Exchange Normal"}}, Slot: 6b}, {id: "thaumcraft:caster_basic", Count: 1b, Damage: 0s, tag: {focus: {id: "thaumcraft:focus_3", Count: 1b, Damage: 0s, tag: {package: {power: 1.0f, complexity: 5, nodes: [{type: "MEDIUM", key: "ROOT"}, {type: "MEDIUM", key: "thaumcraft.TOUCH"}, {type: "EFFECT", key: "thaumcraft.EXCHANGE", setting.fortune: 0, setting.silk: 1}]}}}, picked: {id: "minecraft:planks", Count: 1b, Damage: 0s}, display: {Name: "Exchange Silk"}}, Slot: 7b}, {id: "thaumcraft:caster_basic", Count: 1b, Damage: 0s, tag: {focus: {id: "thaumcraft:focus_3", Count: 1b, Damage: 0s, tag: {package: {power: 1.0f, complexity: 17, nodes: [{type: "MEDIUM", key: "ROOT"}, {type: "MEDIUM", key: "thaumcraft.TOUCH"}, {type: "EFFECT", key: "thaumcraft.EXCHANGE", setting.fortune: 4, setting.silk: 0}]}}}, picked: {id: "minecraft:planks", Count: 1b, Damage: 0s}, display: {Name: "Exchange Fortune IV"}}, Slot: 8b}], CustomName: "Exchange supplies"}
setblock -20 64 12 minecraft:chest 2 replace {Items: [{id: "minecraft:diamond", Count: 4b, Damage: 0s, Slot: 0b}], CustomName: "Replace me: 4 diamonds"}
setblock 4 64 -7 minecraft:chest 2 replace {Items: [{id: "thaumcraft:golem", Count: 1b, Damage: 0s, tag: {props: 0L, xp: 0, display: {Name: "Wood walker"}}, Slot: 0b}, {id: "thaumcraft:golem", Count: 1b, Damage: 0s, tag: {props: 72340168526266368L, xp: 0, display: {Name: "Iron smart fine"}}, Slot: 1b}, {id: "thaumcraft:golem", Count: 1b, Damage: 0s, tag: {props: 144115196665790464L, xp: 0, display: {Name: "Clay climber"}}, Slot: 2b}, {id: "thaumcraft:golem", Count: 1b, Damage: 0s, tag: {props: 216455369487024128L, xp: 0, display: {Name: "Brass flyer"}}, Slot: 3b}, {id: "thaumcraft:golem", Count: 1b, Damage: 0s, tag: {props: 288795525161943040L, xp: 0, display: {Name: "Thaumium fighter"}}, Slot: 4b}, {id: "thaumcraft:golem", Count: 1b, Damage: 0s, tag: {props: 360855318223126528L, xp: 0, display: {Name: "Void dart fighter"}}, Slot: 5b}, {id: "thaumcraft:golem_bell", Count: 1b, Damage: 0s, Slot: 6b}, {id: "minecraft:lead", Count: 16b, Damage: 0s, Slot: 7b}], CustomName: "Golems: place to own"}
setblock 6 64 4 minecraft:chest 2 replace {Items: [{id: "minecraft:iron_ingot", Count: 32b, Damage: 0s, Slot: 0b}, {id: "minecraft:gold_ingot", Count: 16b, Damage: 0s, Slot: 1b}], CustomName: "Transfer source"}
setblock 24 64 4 minecraft:chest 2 replace {Items: [], CustomName: "Transfer destination"}
setblock -26 64 17 minecraft:chest 2 replace {Items: [{id: "thaumcraft:seal", Count: 4b, Damage: 1s, Slot: 0b}, {id: "thaumcraft:seal", Count: 4b, Damage: 2s, Slot: 1b}, {id: "thaumcraft:seal", Count: 4b, Damage: 3s, Slot: 2b}, {id: "thaumcraft:seal", Count: 4b, Damage: 4s, Slot: 3b}, {id: "thaumcraft:seal", Count: 4b, Damage: 5s, Slot: 4b}, {id: "thaumcraft:seal", Count: 4b, Damage: 6s, Slot: 5b}, {id: "thaumcraft:seal", Count: 4b, Damage: 7s, Slot: 6b}, {id: "thaumcraft:seal", Count: 4b, Damage: 8s, Slot: 7b}, {id: "thaumcraft:seal", Count: 4b, Damage: 9s, Slot: 8b}, {id: "thaumcraft:seal", Count: 4b, Damage: 10s, Slot: 9b}, {id: "thaumcraft:seal", Count: 4b, Damage: 11s, Slot: 10b}, {id: "thaumcraft:seal", Count: 4b, Damage: 12s, Slot: 11b}, {id: "thaumcraft:seal", Count: 4b, Damage: 13s, Slot: 12b}, {id: "thaumcraft:seal", Count: 4b, Damage: 14s, Slot: 13b}, {id: "thaumcraft:seal", Count: 4b, Damage: 15s, Slot: 14b}, {id: "thaumcraft:seal", Count: 4b, Damage: 16s, Slot: 15b}], CustomName: "All sixteen seals"}
setblock -3 64 -9 minecraft:chest 2 replace {Items: [{id: "thaumcraft:seal", Count: 4b, Damage: 1s, Slot: 0b}, {id: "thaumcraft:seal", Count: 4b, Damage: 2s, Slot: 1b}, {id: "thaumcraft:seal", Count: 4b, Damage: 3s, Slot: 2b}, {id: "thaumcraft:seal", Count: 4b, Damage: 4s, Slot: 3b}, {id: "thaumcraft:seal", Count: 4b, Damage: 5s, Slot: 4b}, {id: "thaumcraft:seal", Count: 4b, Damage: 6s, Slot: 5b}, {id: "thaumcraft:seal", Count: 4b, Damage: 7s, Slot: 6b}, {id: "thaumcraft:seal", Count: 4b, Damage: 8s, Slot: 7b}, {id: "thaumcraft:seal", Count: 4b, Damage: 9s, Slot: 8b}, {id: "thaumcraft:seal", Count: 4b, Damage: 10s, Slot: 9b}, {id: "thaumcraft:seal", Count: 4b, Damage: 11s, Slot: 10b}, {id: "thaumcraft:seal", Count: 4b, Damage: 12s, Slot: 11b}, {id: "thaumcraft:seal", Count: 4b, Damage: 13s, Slot: 12b}, {id: "thaumcraft:seal", Count: 4b, Damage: 14s, Slot: 13b}, {id: "thaumcraft:seal", Count: 4b, Damage: 15s, Slot: 14b}, {id: "thaumcraft:seal", Count: 4b, Damage: 16s, Slot: 15b}], CustomName: "ALL SEALS - spare kit"}
setblock -23 64 25 minecraft:stone
setblock -19 64 25 minecraft:stone
setblock -15 64 25 minecraft:stone
setblock -11 64 25 minecraft:stone
setblock -7 64 25 minecraft:stone
setblock -3 64 25 minecraft:stone
setblock -18 64 31 minecraft:chest 2 replace {Items: [{id: "minecraft:iron_ingot", Count: 16b, Damage: 0s, Slot: 0b}, {id: "minecraft:planks", Count: 32b, Damage: 0s, Slot: 1b}], CustomName: "Seal inventory"}
setblock -25 64 -3 minecraft:standing_sign 8 replace {Text1: '{"text": "EXCHANGE"}', Text2: '{"text": "Normal / Silk"}', Text3: '{"text": "Fortune IV"}', Text4: '{"text": "Sources ahead"}'}
setblock 5 64 -3 minecraft:standing_sign 8 replace {Text1: '{"text": "GOLEMS"}', Text2: '{"text": "Place from chest"}', Text3: '{"text": "Owner = placer"}', Text4: '{"text": "Transfer / wall"}'}
setblock -25 64 20 minecraft:standing_sign 8 replace {Text1: '{"text": "SEALS"}', Text2: '{"text": "16 types in chest"}', Text3: '{"text": "Place on stone"}', Text4: '{"text": "Bell: configure"}'}
setblock 5 64 20 minecraft:standing_sign 8 replace {Text1: '{"text": "COMBAT / REVEAL"}', Text2: '{"text": "Zombie under roof"}', Text3: '{"text": "Wall for reveal"}', Text4: '{"text": "Cow for scanning"}'}
tellraw @a {"text":"TC6 parity stations ready. Fresh research; /function tc_parity:unlock is optional.","color":"gold"}
gamerule gameLoopFunction tc_parity:players
