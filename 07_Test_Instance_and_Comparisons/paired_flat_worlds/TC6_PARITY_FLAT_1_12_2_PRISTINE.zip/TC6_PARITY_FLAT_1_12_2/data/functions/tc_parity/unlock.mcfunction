thaumcraft research @s all
