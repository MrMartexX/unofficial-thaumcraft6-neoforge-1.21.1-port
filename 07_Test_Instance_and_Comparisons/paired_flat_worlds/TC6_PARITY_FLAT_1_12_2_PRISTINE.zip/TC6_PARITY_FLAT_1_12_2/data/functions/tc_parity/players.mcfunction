execute @a[tag=!tc_parity_ready] ~ ~ ~ function tc_parity:kit
