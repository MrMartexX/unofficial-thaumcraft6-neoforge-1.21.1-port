give @s thaumcraft:thaumonomicon 1 0 {}
give @s thaumcraft:thaumometer 1 0 {}
give @s thaumcraft:golem_bell 1 0 {}
give @s thaumcraft:caster_basic 1 0 {focus: {id: "thaumcraft:focus_3", Count: 1b, Damage: 0s, tag: {package: {power: 1.0f, complexity: 5, nodes: [{type: "MEDIUM", key: "ROOT"}, {type: "MEDIUM", key: "thaumcraft.TOUCH"}, {type: "EFFECT", key: "thaumcraft.EXCHANGE", setting.fortune: 0, setting.silk: 0}]}}}, picked: {id: "minecraft:planks", Count: 1b, Damage: 0s}, display: {Name: "Exchange Normal"}}
give @s thaumcraft:caster_basic 1 0 {focus: {id: "thaumcraft:focus_3", Count: 1b, Damage: 0s, tag: {package: {power: 1.0f, complexity: 5, nodes: [{type: "MEDIUM", key: "ROOT"}, {type: "MEDIUM", key: "thaumcraft.TOUCH"}, {type: "EFFECT", key: "thaumcraft.EXCHANGE", setting.fortune: 0, setting.silk: 1}]}}}, picked: {id: "minecraft:planks", Count: 1b, Damage: 0s}, display: {Name: "Exchange Silk"}}
give @s thaumcraft:caster_basic 1 0 {focus: {id: "thaumcraft:focus_3", Count: 1b, Damage: 0s, tag: {package: {power: 1.0f, complexity: 17, nodes: [{type: "MEDIUM", key: "ROOT"}, {type: "MEDIUM", key: "thaumcraft.TOUCH"}, {type: "EFFECT", key: "thaumcraft.EXCHANGE", setting.fortune: 4, setting.silk: 0}]}}}, picked: {id: "minecraft:planks", Count: 1b, Damage: 0s}, display: {Name: "Exchange Fortune IV"}}
give @s minecraft:planks 64 0 {}
give @s minecraft:stone 64 0 {}
give @s minecraft:chest 16 0 {}
