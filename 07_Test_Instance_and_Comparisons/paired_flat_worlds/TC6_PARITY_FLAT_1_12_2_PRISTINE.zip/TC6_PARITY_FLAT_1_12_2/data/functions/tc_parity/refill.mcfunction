give @s thaumcraft:thaumonomicon 1 0 {}
give @s thaumcraft:thaumometer 1 0 {}
give @s thaumcraft:golem_bell 1 0 {}
give @s thaumcraft:caster_basic 1 0 {focus: {id: "thaumcraft:focus_3", Count: 1b, Damage: 0s, tag: {package: {power: 1.0f, complexity: 5, nodes: [{type: "MEDIUM", key: "ROOT"}, {type: "MEDIUM", key: "thaumcraft.TOUCH"}, {type: "EFFECT", key: "thaumcraft.EXCHANGE", setting.fortune: 0, setting.silk: 0}]}}}, picked: {id: "minecraft:planks", Count: 1b, Damage: 0s}, display: {Name: "Exchange Normal"}}
give @s thaumcraft:caster_basic 1 0 {focus: {id: "thaumcraft:focus_3", Count: 1b, Damage: 0s, tag: {package: {power: 1.0f, complexity: 5, nodes: [{type: "MEDIUM", key: "ROOT"}, {type: "MEDIUM", key: "thaumcraft.TOUCH"}, {type: "EFFECT", key: "thaumcraft.EXCHANGE", setting.fortune: 0, setting.silk: 1}]}}}, picked: {id: "minecraft:planks", Count: 1b, Damage: 0s}, display: {Name: "Exchange Silk"}}
give @s thaumcraft:caster_basic 1 0 {focus: {id: "thaumcraft:focus_3", Count: 1b, Damage: 0s, tag: {package: {power: 1.0f, complexity: 17, nodes: [{type: "MEDIUM", key: "ROOT"}, {type: "MEDIUM", key: "thaumcraft.TOUCH"}, {type: "EFFECT", key: "thaumcraft.EXCHANGE", setting.fortune: 4, setting.silk: 0}]}}}, picked: {id: "minecraft:planks", Count: 1b, Damage: 0s}, display: {Name: "Exchange Fortune IV"}}
give @s minecraft:planks 64 0 {}
give @s minecraft:stone 64 0 {}
give @s minecraft:chest 16 0 {}
give @s thaumcraft:seal 4 1 {}
give @s thaumcraft:seal 4 2 {}
give @s thaumcraft:seal 4 3 {}
give @s thaumcraft:seal 4 4 {}
give @s thaumcraft:seal 4 5 {}
give @s thaumcraft:seal 4 6 {}
give @s thaumcraft:seal 4 7 {}
give @s thaumcraft:seal 4 8 {}
give @s thaumcraft:seal 4 9 {}
give @s thaumcraft:seal 4 10 {}
give @s thaumcraft:seal 4 11 {}
give @s thaumcraft:seal 4 12 {}
give @s thaumcraft:seal 4 13 {}
give @s thaumcraft:seal 4 14 {}
give @s thaumcraft:seal 4 15 {}
give @s thaumcraft:seal 4 16 {}
